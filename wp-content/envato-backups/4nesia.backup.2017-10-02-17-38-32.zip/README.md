SEOWP
===

SEOWP is a super flexible and customizable WordPress theme
specially designed for Social Media specialists,
Digital Marketing Agencies, SEO specialists and their clients.

* For features list and theme updates log visit:
  http://themeforest.net/user/lumbermandesigns

* Theme documentation is available here:
  http://docs.lumbermandesigns.com

* For free theme support contact us using the form on the next page:
  http://themeforest.net/item/seo-wp-social-media-and-digital-marketing-agency/8012838/support/contact/


Good luck!
