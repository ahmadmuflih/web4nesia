Our theme language files will be placed in this directory soon.

Please visit the following links to learn more about translating WordPress themes:
http://codex.wordpress.org/Translating_WordPress
